using System.Diagnostics;
using System.IO;
using TMPro;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using Unity.VisualScripting;
using UnityEngine;
public class StarshipAgent : Agent
{
    public Camera mainCamera;
    public Transform landingZone;

    public float jumpForce = 5f;

    private Rigidbody2D startShipRb;

    private int screenshotIndex = 0;

    private string basePath;
    private string uniquePath;
    public float impulsoForce = 2f;
    private int rotacaoForce = 5;
    private int lateralForce = 10;
    public float acceptableRotationAngle = 5.0f; // Ângulo aceitável de rotação
    public float lowVelocityThreshold = 1.5f; // Velocidade baixa aceitável
    public float highVelocityThreshold = 5.0f; // Velocidade alta
    public float landingPlatformY; // Posição Y da plataforma de pouso
    public TextMeshProUGUI velocityTPM;
    public TextMeshProUGUI distanceTPM;
    public GameObject ContainerFlame;
    private SpriteRenderer spriteRenderer;
    private float Fuel = 1000;
    public void CaptureAndSaveScreenshot()
    {


        // Verifica se o diretório existe e cria se não existir
        if (!Directory.Exists(uniquePath))
        {
            try
            {
                Directory.CreateDirectory(uniquePath);
                UnityEngine.Debug.Log($"Diretório criado: {uniquePath}");
            }
            catch (System.Exception e)
            {
                UnityEngine.Debug.LogError($"Falha ao criar o diretório: {e.Message}");
                return; // Não prosseguir se não puder criar o diretório
            }
        }

        string screenshotName = $"screenshot_{screenshotIndex}.png";
        string screenshotPath = Path.Combine(uniquePath, screenshotName);

        try
        {
            ScreenCapture.CaptureScreenshot(screenshotPath);
            UnityEngine.Debug.Log($"Screenshot salva em: {screenshotPath}");
        }
        catch (System.Exception e)
        {
            UnityEngine.Debug.LogError($"Falha ao salvar a captura de tela: {e.Message}");
        }

        screenshotIndex++;
    }
    void Awake()
    {

        // string appPath = Path.GetDirectoryName(Application.absoluteURL);

        basePath = Path.Combine(Application.dataPath.Replace("Contents", "").Replace("Starship2DEnv.app", ""), "IMAGES_Trainning");
        // //  basePath = Path.Combine(Application.dataPath.Replace("FlappyBirdEnv_Data", ""), "IMAGES_Trainning");

        uniquePath = Path.Combine(basePath, System.Guid.NewGuid().ToString());
    }
    void Start()
    {
        spriteRenderer = ContainerFlame.GetComponent<SpriteRenderer>();
        landingPlatformY = landingZone.position.y;
        startShipRb = this.GetComponent<Rigidbody2D>();
        spriteRenderer.enabled = false;

    }

    void FixedUpdate()
    {
        Information();
        // CaptureAndSaveScreenshot();

        // Mover os canos para a esquerda
        // landingZone.position = new Vector2(topPipe.position.x - velocity, topPipe.position.y);
        // bottomPipe.position = new Vector2(topPipe.position.x - velocity, bottomPipe.position.y);

        // // Verificar se os canos saíram da tela
        // if (!IsVisible(topPipe) || !IsVisible(bottomPipe))
        // {
        //     CountPipe++;
        //     Restart();
        // }
    }
    void Restart()
    {
        transform.position = Vector3.zero;
        startShipRb.velocity = Vector2.zero;
        startShipRb.angularVelocity = 0;
        transform.rotation = new Quaternion(0, 0, 0, 0);

        //  9.6
        float landingZonePositionX = Random.Range(8.6f, -8.6f);
        float starshipPositionX = Random.Range(8.6f, -8.6f);
        landingZone.position = new Vector2(landingZonePositionX, landingZone.position.y);
        // landingZone.position = new Vector2(0, landingZone.position.y);

        transform.position = new Vector2(starshipPositionX, 4.5f);
        Fuel = 1000;

    }
    private bool IsVisible(Transform transform)
    {
        Vector2 screenPoint = mainCamera.WorldToViewportPoint(transform.position);
        return screenPoint.x > 0;
    }
    private bool IsVisibleBird(Transform transform)
    {
        Vector2 screenPoint = mainCamera.WorldToViewportPoint(transform.position);
        return screenPoint.y < -1 || screenPoint.y > 1;
    }

    void OnBecameInvisible()
    {
        // topPipe.position = new Vector2(0, topPipe.position.y);
        AddReward(-.1f);
        EndEpisode();
    }

    public override void OnEpisodeBegin()
    {
        Restart();
    }

    public override void CollectObservations(VectorSensor sensor)
    {


        sensor.AddObservation(startShipRb.position.x);
        sensor.AddObservation(startShipRb.position.y);

        // sensor.AddObservation(transform.rotation.z);
        sensor.AddObservation(landingZone.transform.position.x);
        sensor.AddObservation(landingZone.transform.position.y);

        // sensor.AddObservation(Vector2.Distance(startShipRb.position, landingZone.position));
        // sensor.AddObservation(startShipRb.velocity.sqrMagnitude);
        // sensor.AddObservation(startShipRb.angularVelocity);
        // sensor.AddObservation(Fuel);
    }


   public override void OnActionReceived(ActionBuffers actions)
{
    // Ações contínuas
    var continuousActions = actions.ContinuousActions;
    var distance = Vector2.Distance(startShipRb.position, landingZone.position);

    // Movimento lateral (A e D)
    float goLeft = continuousActions[0];
    float goRight = continuousActions[1];
    float goForce = continuousActions[2];

    // Aplicar movimento lateral (exemplo de força lateral)
    startShipRb.AddForce(Vector2.left * goLeft * impulsoForce);
    startShipRb.AddForce(Vector2.right * goRight * impulsoForce);

    // Aplicar força para cima
    startShipRb.AddForce(Vector2.up * goForce * impulsoForce);
    spriteRenderer.enabled = goForce > 0;
    if(spriteRenderer.enabled){
        Fuel--;
    }
   

    // Lógica de pontuação
    if (startShipRb.position.x < -10 || startShipRb.position.x > 10 || startShipRb.position.y < -5 || startShipRb.position.y > 5)
    {
        AddReward(-0.1f);
        EndEpisode();
    }

    if (Fuel < 1)
    {
        AddReward(-0.1f);
        EndEpisode();
    }

    if (distance < 0.7)
    {
        AddReward(0.1f);

        if (startShipRb.velocity.sqrMagnitude < 0.5f)
        {
            AddReward(0.1f);
        }

        if (Mathf.Abs(startShipRb.angularVelocity) < 0.5f)
        {
            AddReward(0.1f);
        }
    }
}


    private void Information()
    {

        GetCumulativeReward();

        var velocity = startShipRb.velocity.sqrMagnitude;
        var distance = Vector2.Distance(transform.position, landingZone.position);
        velocityTPM.text = $"Velocity:{velocity}";
        distanceTPM.text = $"Distance:{distance}\nCumulative Reward:{GetCumulativeReward()}\nFuel:{Fuel}";


        // Altera a cor do texto com base na velocidade
        if (startShipRb.velocity.sqrMagnitude > .5f)
        {
            velocityTPM.color = Color.red; // Cor verde para baixa velocidade
        }
        else
        {
            velocityTPM.color = Color.green; // Cor padrão (ou qualquer outra cor)
        }
    }
   
public override void Heuristic(in ActionBuffers actionsOut)
{
    var ContinuousActions = actionsOut.ContinuousActions;

    // Espaço para adicionar impulso (1) ou não (0)
    ContinuousActions[0] = Input.GetKey(KeyCode.Space) ? 1f : 0f;

    // Seta para esquerda para rotacionar no sentido anti-horário, seta para direita para rotacionar no sentido horário
    if (Input.GetKey(KeyCode.LeftArrow))
    {
        ContinuousActions[1] = -1f;
    }
    else if (Input.GetKey(KeyCode.RightArrow))
    {
        ContinuousActions[1] = 1f;
    }
    else
    {
        ContinuousActions[1] = 0f;
    }

   
      if (Input.GetKey(KeyCode.UpArrow))
    {
        ContinuousActions[2] = 1f;
    }
    else
    {
        ContinuousActions[2] = 0f;
    }
}


    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Verificar se tocou a plataforma de pouso 


        if (transform.rotation.z > 10 || transform.rotation.z < -10)
        {
            AddReward(-0.1f);
            EndEpisode();
        }



        if (startShipRb.velocity.sqrMagnitude < .5f)
        {
            AddReward(0.1f);
        }
        else
        {
            AddReward(-0.1f);

        }

        if (startShipRb.angularVelocity < .5f)
        {
            AddReward(0.1f);

        }
        else
        {
            AddReward(-0.1f);
        }

        EndEpisode();



    }



}
