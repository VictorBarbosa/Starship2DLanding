using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainScript : MonoBehaviour
{


    void Awake()
    {

        var starShipTexture = Resources.Load<Texture2D>("StarShip");
        gameObject.transform.localScale = new Vector3(0.0977f, 0.10291f, 0.64f);
        gameObject.transform.localRotation = new Quaternion(0, 0, 0, 0);
        gameObject.transform.position = new Vector3(-16.91f, -8.800f, 0f);
        gameObject.transform.parent = this.transform;

        var rb = gameObject.AddComponent<Rigidbody2D>();
        var bc = gameObject.AddComponent<BoxCollider2D>();
        bc.offset = new Vector2(0, 0);
        bc.size = new Vector2(3.8f, 9.55f);

        // Adiciona componentes e personaliza o novo GameObject conforme necessário
        var sr = gameObject.AddComponent<SpriteRenderer>(); // Adiciona um componente SpriteRenderer, por exemplo
        sr.sprite = Sprite.Create(starShipTexture, new Rect(0, 0, starShipTexture.width, starShipTexture.height), new Vector2(0.5f, 0.5f));



        // var rocketInstance2 = Resources.Load<Texture2D>("lander");
        // var GameObjectRocket2 = Instantiate(rocketInstance2);



    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
