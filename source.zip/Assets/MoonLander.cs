using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoonLander : MonoBehaviour
{

    void Awake()
    {

        var rocketInstance = Resources.Load<GameObject>("Starship");
        var GameObjectRocket = Instantiate(rocketInstance);

        var rocketInstance2 = Resources.Load<GameObject>("lander");
        var GameObjectRocket2 = Instantiate(rocketInstance);

        var collision = GameObjectRocket.AddComponent<Landing>();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
